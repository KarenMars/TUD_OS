#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>
#include <string.h>

unsigned int key_space;

//define the functipn pointer
typedef void * (*ResolveCollisionCallback)(void * , void * );
typedef void * (*DestroyDataCallback)(void * );
typedef unsigned int(*hashfunc)(const char * );
//define hashnodes
typedef struct HashNodes HashNodes;
struct HashNodes
{
	char * key;
	void * value;
	struct HashNodes* next; 
};
//define hashmap
typedef struct HashMap HashMap;
struct HashMap
{ 
	unsigned int key_space; 
	HashNodes **bucket;
	hashfunc hash; // a pointer to hash_value function 
};

HashMap * create_hashmap(unsigned int key_space);



unsigned int hash(const char *key);

void insert_data(HashMap * hm, const char *key, void * data, ResolveCollisionCallback resolve_collision);

void * get_data(HashMap *hm, const char *key) ;

void iterate(HashMap *hm, void (*callback)(const char*, void *));

void remove_data(HashMap *hm, const char *key, DestroyDataCallback destroy_data); 

void delete_hashmap(HashMap *hm, DestroyDataCallback destroy_data);