// /*2018-12-12 HashMap Hang Ji 4759745*/
// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// #include <assert.h>
// //define the function

// //define a link list for a bucket
// typedef struct HashNodes HashNodes
// struct HashNodes
// {
// 	const char * key;
// 	void * value;
// 	struct HashNodes* next;
// };
// //define a hashmap
// typedef struct HashMap HashMap
// struct HashMap
// { 
// 	size_t key_space; 
// 	HashNodes **bucket;
// 	hashfunc hash; // a pointer to hash_value function 
// };
//creating a hashmap
#include "hashmap.h"


// struct HashNodes
// {
// 	const char * key;
// 	void * value;
// 	struct HashNodes* next;
// };

// struct HashMap

// { 
// 	size_t key_space; 
// 	HashNodes **bucket;
// 	hashfunc hash; // a pointer to hash_value function 
// };

// //define the functipn pointer
// typedef void * (*ResolveCollisionCallback)(void * , void * );
// typedef void * (*DestroyDataCallback)(void * );
// typedef unsigned int(*hashfunc)(const char * );
// //define hashnodes
// typedef struct HashNodes HashNodes;
// struct HashNodes
// {
// 	const char * key;
// 	void * value;
// 	struct HashNodes* next;
// };
// //define hashmap
// typedef struct HashMap HashMap;
// struct HashMap
// { 
// 	size_t key_space; 
// 	HashNodes **bucket;
// 	hashfunc hash; // a pointer to hash_value function 
// };


unsigned int key_space; // global value 

HashMap* create_hashmap(unsigned int key_space)
{
	HashMap * new_hm;

	if (key_space<1)
	{
		printf("Invalid key_space");
		return NULL;
	}
	
	new_hm = (HashMap *)malloc(sizeof(HashMap));

	new_hm->key_space = key_space;
	new_hm->hash = hash;

	new_hm->bucket = (HashNodes **)malloc(sizeof(HashNodes * )* key_space);

	for (unsigned int i = 0; i<key_space; i++)
	{
		new_hm->bucket[i] = NULL;
	}

	return new_hm;
	// /*allocate the map itself.*/
	// if ((new_hm = malloc(sizeof(HashMap))) == NULL ) 
	// {
	// 	return NULL;
	// }
    
	// /*allocate pointers to the head nodes*/
	// if ((new_hm->bucket = malloc(sizeof(HashNodes * )* key_space)) == NULL)
	// {
	// 	return NULL;  
	// }

	// for (unsigned int i = 0; i<key_space; i++)
	// {
	// 	new_hm->bucket[i] = calloc(1,sizeof(HashNodes*));
	// 	new_hm->bucket[i] = NULL;
		
	// }

	// new_hm->key_space = key_space;
	// new_hm->hash = hash; // ???????

	// return new_hm;
}
//computer index
unsigned int hash(const char * key)
{
	unsigned int sum = 0;
	unsigned int length;
	length = strlen(key);
	for (unsigned int i = 0; i<length; i++)
	{
		sum = sum + key[i];
	}
	
	return sum; 
}
//insert data 
void insert_data(HashMap * hm, const char * key, void * data, ResolveCollisionCallback resolve_collision)
{	
	unsigned int index = 0;
	index = hm->hash(key)%(hm->key_space);
	HashNodes * pointer;

	pointer = hm->bucket[index];
	//no key collision
	if ( hm->bucket[index] == NULL)
	{	
		hm->bucket[index] = (HashNodes *)calloc(1, sizeof(HashNodes));
		hm->bucket[index]->key = (char *)calloc(1, strlen(key)+1); 
		strcpy(hm->bucket[index]->key, key);
		hm->bucket[index]->value = data;
		hm->bucket[index]->next = NULL;
		return; 
	}
	//key collision
	else
	{	//check every hashnode in the corresponding bucket[index]
		while ( pointer != NULL)
		{
			if(strcmp(pointer->key, key) == 0)
			{
				pointer->value = resolve_collision(pointer->value, data);
				return;
			} 
			pointer = pointer->next;
		}
		if (pointer == NULL)
		{
	    	pointer = (HashNodes *)calloc(1, sizeof(HashNodes));
			pointer->key = (char *)calloc(1, strlen(key)+1);
			strcpy(pointer->key, key);
			pointer->value = data;
			pointer->next = hm->bucket[index];
			hm->bucket[index] = pointer;
			return;
		}

 		// for (pointer = hm->bucket[index]; pointer != NULL; pointer = pointer->next)
 		// {
 		// 	if ( strcmp(pointer->key, key) == 0)
 		// 	{	
 		// 		resolve_collision(pointer->value, data);
 		// 		return;
 		// 	}
 		// }
 		//if the index of the keys are the same and the keys are different
 		//insert it at the head of the link list 
 		// if (pointer == NULL)
 		// {
 		// 	pointer = calloc(1,sizeof(HashNodes));
 		// 	pointer->key = calloc(1,sizeof(key)+1);
 		// 	strcpy(pointer->key, key);
 		// 	pointer->value = data;
 		// 	pointer->next = hm->bucket[index];
 		// 	hm->bucket[index] = pointer;
 		// 	return;
 		// }
 	}
}

//retrieving data
void * get_data(HashMap * hm, const char * key)
{
	unsigned int index;
	index = hm->hash(key)%hm->key_space;
	HashNodes * pointer;
	pointer = hm->bucket[index];
	if (pointer == NULL)
	{
		return NULL;
	}
	else
	{	while ( pointer != NULL)
		{
			if (strcmp(pointer->key, key) == 0)
			{	
				return pointer->value;
			}
			pointer = pointer->next;
	
		}
		
		return NULL;
	}
}
//iterator
void iterate(HashMap * hm, void (*callback)(const char * key, void * data))
{
	unsigned int i;
	HashNodes * pointer;

	for (i=0; i<hm->key_space; i++)
	{	
		pointer = hm->bucket[i];
		while (pointer != NULL)
		{
			callback(pointer->key, pointer->value);
			pointer = pointer->next;
		}
	}
	return;
}
//removing data
void remove_data(HashMap * hm, const char * key, DestroyDataCallback destroy_data)
{	
	unsigned int index;
	index = hm->hash(key)%hm->key_space;
	if (hm->bucket[index] == NULL)
	{
		return;
	}
	else
	{	
		HashNodes * pointer = hm->bucket[index];
		HashNodes * pre_pointer = pointer;
		//if the key is connected to the head 
		if ( strcmp(pointer->key,key) == 0 && pointer == hm->bucket[index]) 
		{
			if ( destroy_data!= NULL)
			{
				destroy_data(pointer->value);
			}
			
			hm->bucket[index]=pointer->next;
			free(pointer->key);
			free(pointer);
			return;
		}
		else
		{
			while ( pointer != NULL )
			{
				if ( strcmp(pointer->key, key) == 0 )
				{
					if ( destroy_data != NULL)
					{
						destroy_data(pointer->value);
					}
					pre_pointer->next = pointer->next; 
					free(pointer->key);
					free(pointer);
					return;
				}
				pre_pointer = pointer;
				pointer = pointer->next;
			}
		}
		return;
		// if ( pointer != NULL && destroy_data !=NULL )
		// {
		// 	HashNodes * tmp = pointer->next;
		// 	pointer->next = tmp->next;
		// 	tmp->next = NULL;
		// 	free(tmp->key);
		// 	free(tmp);
		// }
		// return;
	}
}
//Deleting a hash map
void delete_hashmap(HashMap * hm, DestroyDataCallback destroy_data)
{
	unsigned int i;
	HashNodes * pointer;
	HashNodes * next_pointer;
	if ( hm == NULL)
	{
		return;
	}
	else
	{
		for ( i=0; i<hm->key_space; i++ )
		{	
			pointer = hm->bucket[i];
			while (pointer!=NULL)
			{	next_pointer = pointer->next;
				if ( destroy_data != NULL)
				{
					destroy_data(pointer->value);
				}
				free(pointer->key); 
				free(pointer);
				pointer = next_pointer;
			}
			
		}
		free(hm->bucket);
		free(hm);
		return;
	}




	// if ( destroy_data != NULL )
	// {
	// 	for ( i=0; i<hm->key_space; i++ )
	// 	{
	// 		for (pointer = hm->bucket[i]; pointer != NULL; pointer = pointer->next)
	// 		{
	// 			destroy_data(pointer->value);
	// 			free(pointer->key);
	// 		}
	// 		free(hm->bucket[i]);
	// 	}
	// 	free(hm);		
	// }
	// return;
}



